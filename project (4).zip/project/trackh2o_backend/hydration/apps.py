from django.apps import AppConfig


class HydrationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hydration'
