from django.shortcuts import render, redirect
from rest_framework import viewsets, permissions
from .models import WaterIntake
from .serializers import WaterIntakeSerializer
from django.contrib.auth.models import User
from django.contrib import messages

class WaterIntakeViewSet(viewsets.ModelViewSet):
    queryset = WaterIntake.objects.all()
    serializer_class = WaterIntakeSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return WaterIntake.objects.filter(user=self.request.user).order_by('-date')

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

def index(request):
    return render(request, 'index.html')

def signup(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        email = request.POST['email']
        
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists")
            return redirect('signup')

        user = User.objects.create_user(username=username, email=email, password=password)
        user.save()
        messages.success(request, "User created successfully")
        return redirect('signin')
    return render(request, 'signup.html')
def signup_page(request):
    return render(request, 'signup.html')


def signin(request):
    return render(request, 'signin.html')


def profile(request):
    return render(request, 'profile.html')

def timersetuop(request):
    return render(request, 'timersetuop.html')

def history(request):
    return render(request, 'history.html')

def home(request):
    return render(request, 'home.html')
