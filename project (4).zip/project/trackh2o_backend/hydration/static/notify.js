function showHydrationReminder() {
    if (Notification.permission === "granted") {
        new Notification("TrackH2O Reminder", {
            body: "Time to drink water and stay hydrated! 💧",
            icon: "your-icon.png"
        });
    }
}

function requestNotificationPermission() {
    if (Notification.permission !== "granted") {
        Notification.requestPermission().then(permission => {
            if (permission === "granted") {
                console.log("Notification permission granted.");
            }
        });
    }
}

setInterval(() => {
    const currentHour = new Date().getHours();
    if ([9, 11, 13, 15, 17].includes(currentHour)) {
        showHydrationReminder();
    }
}, 3600000);
