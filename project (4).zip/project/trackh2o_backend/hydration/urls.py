from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),

    # Sign In
    path('signin/', views.signin, name='signin_page'),
    path('api/signin/', views.signin, name='signin'),

    # Sign Up
    path('signup/', views.signup_page, name='signup_page'),
    path('api/signup/', views.signup, name='signup'),

    # Other Pages
    path('timersetuop/', views.timersetuop, name='timersetuop'),
    path('home/', views.home, name='home'),
    path('profile/', views.profile, name='profile'),
    path('history/', views.history, name='history'),
]
