from django.db import models
from django.contrib.auth.models import User

class WaterIntake(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    date = models.DateField(auto_now_add=True)
    amount_ml = models.PositiveIntegerField()

    def __str__(self):
        return f"{self.user.username} - {self.date}: {self.amount_ml}ml"

# Create your models here.
