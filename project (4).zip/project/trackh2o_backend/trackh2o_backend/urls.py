from django.contrib import admin
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from hydration.views import WaterIntakeViewSet
from hydration import views  # 👈 Yeh line add karo

router = DefaultRouter()
router.register(r'intake', WaterIntakeViewSet)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('hydration.urls')),

    path('api/', include(router.urls)),
    path('api-auth/', include('rest_framework.urls')),
      path('', include('hydration.urls')),

    # path('', views.home_view, name='home'),
#     path('signup/', views.signup_view, name='signup'),
#     path('signin/', views.signin_view, name='signin'),
#      path('profile/', views.profile_view, name='profile'),
#     path('timersetup/', views.timer_setup_view, name='timersetup'),
#     path('history/', views.history_view, name='history'),
 ]
